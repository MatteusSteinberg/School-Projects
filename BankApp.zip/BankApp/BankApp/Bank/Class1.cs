﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankApp.Bank
{
    class Class1
{
        public string Name { get; set; }

        public string Address { get; set; }

        public int bankNumber { get; set; }
        public int Deposit { get; set; }
        public int Withdraw { get; set; }
    }
}
